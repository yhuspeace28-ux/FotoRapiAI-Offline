package com.fotorapi.offline

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class MaskView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var imageWidth = 0
    private var imageHeight = 0
    private var maskBitmap: Bitmap? = null
    private var maskCanvas: Canvas? = null

    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(115, 255, 64, 129)
        style = Paint.Style.FILL
    }

    private var brushPx = 120f

    fun setImageSize(width: Int, height: Int) {
        imageWidth = width
        imageHeight = height
        recreateMask()
        invalidate()
    }

    private fun recreateMask() {
        maskBitmap?.recycle()
        if (imageWidth <= 0 || imageHeight <= 0) {
            maskBitmap = null
            maskCanvas = null
            return
        }
        maskBitmap = Bitmap.createBitmap(
            imageWidth,
            imageHeight,
            Bitmap.Config.ALPHA_8
        )
        maskCanvas = Canvas(maskBitmap!!)
        maskCanvas?.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bitmap = maskBitmap ?: return
        val rect = displayRect()

        canvas.save()
        canvas.clipRect(rect)
        canvas.drawBitmap(bitmap, null, rect, previewPaint)
        canvas.restore()
    }

    private fun displayRect(): RectF {
        if (imageWidth <= 0 || imageHeight <= 0) return RectF()

        val viewW = width.toFloat()
        val viewH = height.toFloat()
        val scale = min(viewW / imageWidth, viewH / imageHeight)

        val drawW = imageWidth * scale
        val drawH = imageHeight * scale

        return RectF(
            (viewW - drawW) / 2f,
            (viewH - drawH) / 2f,
            (viewW + drawW) / 2f,
            (viewH + drawH) / 2f
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (maskBitmap == null) return false

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_MOVE,
            MotionEvent.ACTION_UP -> {
                paintAt(event.x, event.y)
                invalidate()
                return true
            }
        }
        return true
    }

    private fun paintAt(screenX: Float, screenY: Float) {
        val rect = displayRect()
        if (!rect.contains(screenX, screenY)) return

        val bx = ((screenX - rect.left) / rect.width() * imageWidth)
            .coerceIn(0f, imageWidth - 1f)

        val by = ((screenY - rect.top) / rect.height() * imageHeight)
            .coerceIn(0f, imageHeight - 1f)

        maskCanvas?.drawCircle(bx, by, brushPx / 2f, maskPaint)
    }

    fun clearMask() {
        maskCanvas?.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        invalidate()
    }

    fun getKeepMask(): Bitmap? {
        val source = maskBitmap ?: return null
        val keep = Bitmap.createBitmap(
            source.width,
            source.height,
            Bitmap.Config.ALPHA_8
        )
        val c = Canvas(keep)
        c.drawColor(Color.WHITE)
        val erasePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.FILL
        }

        val pixels = ByteArray(source.width * source.height)
        source.copyPixelsToBuffer(java.nio.ByteBuffer.wrap(pixels))
        val out = ByteArray(pixels.size)

        for (i in pixels.indices) {
            out[i] = if ((pixels[i].toInt() and 0xFF) > 20) 0 else 255
        }

        keep.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(out))
        return keep
    }

    fun setBrushSize(px: Float) {
        brushPx = px.coerceIn(20f, 500f)
    }
}
