package com.fotorapi.offline

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var photoView: ImageView
    private lateinit var maskView: MaskView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var bitmap: Bitmap? = null
    private val executor = Executors.newSingleThreadExecutor()

    private val picker =
        registerForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) loadPhoto(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        photoView = findViewById(R.id.photoView)
        maskView = findViewById(R.id.maskView)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.statusText)

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            picker.launch("image/*")
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            maskView.clearMask()
            status.text = "Mask direset"
        }

        findViewById<Button>(R.id.btnRemove).setOnClickListener {
            removeObject()
        }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            savePhoto()
        }

        findViewById<Button>(R.id.btnNatural).setOnClickListener {
            applyNatural()
        }
    }

    private fun loadPhoto(uri: Uri) {
        executor.execute {
            try {
                val bmp = decodeOriented(uri)
                runOnUiThread {
                    bitmap = bmp
                    photoView.setImageBitmap(bmp)
                    maskView.setImageSize(bmp.width, bmp.height)
                    status.text = "${bmp.width} × ${bmp.height}"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Gagal membuka foto: ${e.message}"
                }
            }
        }
    }

    private fun decodeOriented(uri: Uri): Bitmap {
        val stream = contentResolver.openInputStream(uri)
            ?: error("Tidak dapat membuka foto")

        val original = BitmapFactory.decodeStream(stream)
        stream.close()

        requireNotNull(original) {
            "Format foto tidak didukung"
        }

        val exifStream = contentResolver.openInputStream(uri)
        val orientation = if (exifStream != null) {
            ExifInterface(exifStream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
        } else {
            ExifInterface.ORIENTATION_NORMAL
        }
        exifStream?.close()

        val matrix = Matrix()

        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 ->
                matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 ->
                matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 ->
                matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL ->
                matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL ->
                matrix.postScale(1f, -1f)
        }

        if (matrix.isIdentity) return original

        return Bitmap.createBitmap(
            original,
            0,
            0,
            original.width,
            original.height,
            matrix,
            true
        )
    }

    private fun removeObject() {
        val source = bitmap ?: run {
            status.text = "Pilih foto dulu"
            return
        }

        val keepMask = maskView.getKeepMask() ?: run {
            status.text = "Coret objek dulu"
            return
        }

        setBusy(true)
        status.text = "AI offline memproses..."

        executor.execute {
            try {
                MiganInpainter(this).use { ai ->
                    val result = ai.removeObject(
                        source,
                        keepMask
                    ) { done, total ->
                        runOnUiThread {
                            status.text = "AI offline: $done/$total"
                        }
                    }

                    runOnUiThread {
                        bitmap = result
                        photoView.setImageBitmap(result)
                        maskView.clearMask()
                        setBusy(false)
                        status.text =
                            "Selesai • ${result.width} × ${result.height}"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    status.text = "AI gagal: ${e.message}"
                }
            }
        }
    }

    private fun applyNatural() {
        val source = bitmap ?: return
        setBusy(true)
        status.text = "Menerapkan warna natural..."

        executor.execute {
            val out = source.copy(Bitmap.Config.ARGB_8888, true)
            val pixels = IntArray(out.width * out.height)
            out.getPixels(
                pixels,
                0,
                out.width,
                0,
                0,
                out.width,
                out.height
            )

            for (i in pixels.indices) {
                val c = pixels[i]
                val r = ((c shr 16) and 255)
                val g = ((c shr 8) and 255)
                val b = (c and 255)

                val avg = (r + g + b) / 3
                val factor = when {
                    avg < 40 -> 1.04f
                    avg > 220 -> 0.98f
                    else -> 1.02f
                }

                val nr = (r * factor).coerceIn(0f, 255f).toInt()
                val ng = (g * factor).coerceIn(0f, 255f).toInt()
                val nb = (b * factor).coerceIn(0f, 255f).toInt()

                pixels[i] =
                    0xFF000000.toInt() or
                    (nr shl 16) or
                    (ng shl 8) or nb
            }

            out.setPixels(
                pixels,
                0,
                out.width,
                0,
                0,
                out.width,
                out.height
            )

            runOnUiThread {
                bitmap = out
                photoView.setImageBitmap(out)
                setBusy(false)
                status.text = "Warna natural diterapkan"
            }
        }
    }

    private fun savePhoto() {
        val bmp = bitmap ?: run {
            status.text = "Belum ada foto"
            return
        }

        val name = "FotoRapiAI_${System.currentTimeMillis()}.jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/FotoRapiAI"
            )
        }

        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        )

        if (uri == null) {
            status.text = "Gagal membuat file"
            return
        }

        contentResolver.openOutputStream(uri)?.use { out ->
            bmp.compress(
                Bitmap.CompressFormat.JPEG,
                98,
                out
            )
        }

        status.text = "Disimpan ke Pictures/FotoRapiAI"
    }

    private fun setBusy(busy: Boolean) {
        progress.visibility =
            if (busy) View.VISIBLE else View.GONE

        findViewById<Button>(R.id.btnPick).isEnabled = !busy
        findViewById<Button>(R.id.btnNatural).isEnabled = !busy
        findViewById<Button>(R.id.btnReset).isEnabled = !busy
        findViewById<Button>(R.id.btnRemove).isEnabled = !busy
        findViewById<Button>(R.id.btnSave).isEnabled = !busy
        maskView.isEnabled = !busy
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
