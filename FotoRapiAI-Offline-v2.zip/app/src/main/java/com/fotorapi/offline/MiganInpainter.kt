package com.fotorapi.offline

import android.content.Context
import android.graphics.Bitmap
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.TensorBuffer
import kotlin.math.max
import kotlin.math.min

class MiganInpainter(context: Context) : AutoCloseable {

    private val model: CompiledModel
    private val inputs: List<TensorBuffer>
    private val outputs: List<TensorBuffer>

    private val input = FloatArray(4 * 512 * 512)

    init {
        model = try {
            CompiledModel.create(
                context.assets,
                "migan_fp16.tflite",
                CompiledModel.Options(Accelerator.GPU, Accelerator.CPU)
            )
        } catch (_: Throwable) {
            CompiledModel.create(
                context.assets,
                "migan_fp16.tflite",
                CompiledModel.Options(Accelerator.CPU)
            )
        }

        inputs = model.createInputBuffers()
        outputs = model.createOutputBuffers()

        require(inputs.size == 1) { "MI-GAN membutuhkan 1 input tensor" }
        require(outputs.size == 1) { "MI-GAN membutuhkan 1 output tensor" }
    }

    fun removeObject(
        source: Bitmap,
        keepMask: Bitmap,
        progress: ((Int, Int) -> Unit)? = null
    ): Bitmap {
        require(source.width == keepMask.width)
        require(source.height == keepMask.height)

        val width = source.width
        val height = source.height

        val rawMask = ByteArray(width * height)
        keepMask.copyPixelsToBuffer(
            java.nio.ByteBuffer.wrap(rawMask)
        )

        // Sedikit perluas area hapus supaya tepi objek, bingkai, rambut,
        // dan bagian kecil yang luput dari kuas ikut masuk ke inpainting.
        val mask = dilateEraseMask(
            rawMask,
            width,
            height,
            radius = 20
        )

        val erase = findEraseBounds(mask, width, height)
            ?: return source.copy(Bitmap.Config.ARGB_8888, true)

        val xs = tileStarts(width, erase[0], erase[2])
        val ys = tileStarts(height, erase[1], erase[3])
        val total = xs.size * ys.size

        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        var done = 0

        for (y in ys) {
            for (x in xs) {
                val output = inferTile(source, mask, x, y)
                pasteTile(result, mask, x, y, output)
                done++
                progress?.invoke(done, total)
            }
        }

        return result
    }

    /**
     * Morphological dilation pada area erase menggunakan sliding window.
     * 0 = erase, 255 = keep.
     */
    private fun dilateEraseMask(
        source: ByteArray,
        width: Int,
        height: Int,
        radius: Int
    ): ByteArray {
        if (radius <= 0) return source.copyOf()

        val horizontal = ByteArray(source.size)
        val output = ByteArray(source.size)
        val window = radius * 2 + 1

        for (y in 0 until height) {
            val row = y * width
            var count = 0
            var right = min(width - 1, radius)
            for (x in 0..right) {
                if ((source[row + x].toInt() and 0xFF) < 128) count++
            }

            for (x in 0 until width) {
                horizontal[row + x] = if (count > 0) 0 else 255

                val removeX = x - radius
                if (removeX >= 0 &&
                    (source[row + removeX].toInt() and 0xFF) < 128
                ) {
                    count--
                }

                val addX = x + radius + 1
                if (addX < width &&
                    (source[row + addX].toInt() and 0xFF) < 128
                ) {
                    count++
                }
            }
        }

        for (x in 0 until width) {
            var count = 0
            val initialBottom = min(height - 1, radius)
            for (y in 0..initialBottom) {
                if ((horizontal[y * width + x].toInt() and 0xFF) < 128) {
                    count++
                }
            }

            for (y in 0 until height) {
                output[y * width + x] = if (count > 0) 0 else 255

                val removeY = y - radius
                if (removeY >= 0 &&
                    (horizontal[removeY * width + x].toInt() and 0xFF) < 128
                ) {
                    count--
                }

                val addY = y + radius + 1
                if (addY < height &&
                    (horizontal[addY * width + x].toInt() and 0xFF) < 128
                ) {
                    count++
                }
            }
        }

        return output
    }

    private fun findEraseBounds(
        mask: ByteArray,
        width: Int,
        height: Int
    ): IntArray? {
        var left = width
        var top = height
        var right = -1
        var bottom = -1

        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                val keep = mask[row + x].toInt() and 0xFF
                if (keep < 128) {
                    left = min(left, x)
                    top = min(top, y)
                    right = max(right, x)
                    bottom = max(bottom, y)
                }
            }
        }

        if (right < 0) return null

        val pad = 160
        return intArrayOf(
            max(0, left - pad),
            max(0, top - pad),
            min(width - 1, right + pad),
            min(height - 1, bottom + pad)
        )
    }

    private fun tileStarts(
        size: Int,
        start: Int,
        end: Int
    ): IntArray {
        if (size <= 512) return intArrayOf(0)

        val result = ArrayList<Int>()
        val stride = 384
        var p = max(0, (start / stride) * stride)

        while (true) {
            result.add(p)
            if (p + 512 >= end || p + 512 >= size) break
            p += stride
        }

        // Pastikan tepi kanan/bawah selalu ikut ter-cover.
        val last = size - 512
        if (result.last() != last && last >= 0) {
            result.add(last)
        }

        return result.distinct().sorted().toIntArray()
    }

    private fun inferTile(
        source: Bitmap,
        mask: ByteArray,
        tileX: Int,
        tileY: Int
    ): FloatArray {
        val width = source.width
        val height = source.height
        val plane = 512 * 512
        val pixels = IntArray(512 * 512)

        val srcW = min(512, width - tileX)
        val srcH = min(512, height - tileY)

        source.getPixels(
            pixels,
            0,
            srcW,
            tileX,
            tileY,
            srcW,
            srcH
        )

        for (y in 0 until 512) {
            val sy = min(height - 1, tileY + y)
            for (x in 0 until 512) {
                val sx = min(width - 1, tileX + x)
                val c = pixels[
                    min(srcH - 1, y) * srcW +
                        min(srcW - 1, x)
                ]

                val keep =
                    (mask[sy * width + sx].toInt() and 0xFF) / 255f

                val r = ((c shr 16) and 255) / 127.5f - 1f
                val g = ((c shr 8) and 255) / 127.5f - 1f
                val b = (c and 255) / 127.5f - 1f

                val i = y * 512 + x

                input[i] = keep - 0.5f
                input[plane + i] = r * keep
                input[2 * plane + i] = g * keep
                input[3 * plane + i] = b * keep
            }
        }

        inputs[0].writeFloat(input)
        model.run(inputs, outputs)
        return outputs[0].readFloat()
    }

    private fun pasteTile(
        result: Bitmap,
        mask: ByteArray,
        tileX: Int,
        tileY: Int,
        output: FloatArray
    ) {
        val width = result.width
        val height = result.height
        val plane = 512 * 512

        val left = if (tileX == 0) 0 else 64
        val top = if (tileY == 0) 0 else 64
        val right = min(512, width - tileX) -
            if (tileX + 512 < width) 64 else 0
        val bottom = min(512, height - tileY) -
            if (tileY + 512 < height) 64 else 0

        if (right <= left || bottom <= top) return

        val w = right - left
        val h = bottom - top
        val pixels = IntArray(w * h)
        result.getPixels(
            pixels,
            0,
            w,
            tileX + left,
            tileY + top,
            w,
            h
        )

        var p = 0
        for (y in top until bottom) {
            for (x in left until right) {
                val globalX = tileX + x
                val globalY = tileY + y
                val keep =
                    (mask[globalY * width + globalX].toInt() and 0xFF) >= 128

                if (!keep) {
                    val i = y * 512 + x

                    // MI-GAN output is [R plane, G plane, B plane].
                    val r = ((output[i] + 1f) * 127.5f)
                        .coerceIn(0f, 255f).toInt()
                    val g = ((output[plane + i] + 1f) * 127.5f)
                        .coerceIn(0f, 255f).toInt()
                    val b = ((output[2 * plane + i] + 1f) * 127.5f)
                        .coerceIn(0f, 255f).toInt()

                    pixels[p] =
                        0xFF000000.toInt() or
                            (r shl 16) or
                            (g shl 8) or b
                }
                p++
            }
        }

        result.setPixels(
            pixels,
            0,
            w,
            tileX + left,
            tileY + top,
            w,
            h
        )
    }

    override fun close() {
        inputs.forEach { it.close() }
        outputs.forEach { it.close() }
        model.close()
    }
}
