# FotoRapiAI Offline v2

Android photo editor focused on natural color and offline MI-GAN object removal.

- No cloud processing
- MI-GAN LiteRT model downloaded during GitHub Actions build
- EXIF orientation handling
- Original image dimensions preserved
- Mask mapped to the displayed image
